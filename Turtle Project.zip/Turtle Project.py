
import turtle
import math
# Set the amplitude and frequency for the sine wave
amplitude = 160
frequency = 120
turtle.delay(0)
# Define a function to draw a sine wave
def myFunction():
    # Create a turtle graphics screen
    a = turtle.Turtle()  # Create a turtle for drawing
    b = turtle.Turtle()
    c = turtle.Turtle()
    d = turtle.Turtle()
    e= turtle.Turtle()
    b.color('green')
    b.shape('square')
    a.color('blue')  # Set the turtle's color
    a.shape('circle')  # Set the turtle's shape (optional)
    c.color('red')
    c.shape('turtle')
    d.color('black')
    d.shape('square')
    # Loop to draw the sine wave
    for i in range(0,720):
        y = int(amplitude*math.sin((math.pi*frequency)+math.radians(i)))
        x = float((amplitude/3) * math.sin((math.pi * frequency) + math.radians(3*i)))
        z = float((amplitude / 5) * math.sin((math.pi * frequency)+ math.radians(5*i)))
        p = float((amplitude / 7) * math.sin((math.pi * frequency)+ math.radians(7*i)))
        o = float(x+y+z+p)
        # Move the turtle to the specified coordinates
        a.goto(i,y)
        b.goto(i,x)
        c.goto(i,z)
        d.goto(i,o)
        e.goto(i,p)

# Check if amplitude and frequency are greater than zero
while amplitude > 0 and frequency > 0:
    myFunction()

